import { z } from "zod";
export const callMetricSchema = z.object({
  id: z.string(), stage: z.string(), model: z.string(), provider: z.string(), effort: z.string(), maxOutputTokens: z.number(),
  startedAt: z.string(), durationMs: z.number(), status: z.number(), truncated: z.boolean(),
  inputTokens: z.number().optional(), outputTokens: z.number().optional(), totalTokens: z.number().optional(), cachedInputTokens: z.number().optional(), reasoningTokens: z.number().optional(),
});
export type CallMetric = z.infer<typeof callMetricSchema>;
export const executionSchema = z.object({ startedAt: z.string(), updatedAt: z.string(), calls: z.array(callMetricSchema), config: z.record(z.string(),z.unknown()).optional() });
export type Execution = z.infer<typeof executionSchema>;
export function mergeExecution(previous: Execution | undefined, delta: Execution): Execution {
  const calls=[...new Map([...(previous?.calls??[]),...delta.calls].map(call=>[call.id,call])).values()].sort((a,b)=>a.startedAt.localeCompare(b.startedAt));
  return { startedAt: previous && previous.startedAt < delta.startedAt ? previous.startedAt : delta.startedAt, updatedAt: delta.updatedAt, calls, config: delta.config ?? previous?.config };
}
