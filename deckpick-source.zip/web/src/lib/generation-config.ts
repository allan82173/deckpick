export type GenerationStage = "interpretTask" | "judgment" | "story" | "assessDeck" | "planResearch" | "research" | "evidence" | "attachments" | "candidates" | "formatRepair" | "headlineRepair" | "slideChat" | "keyCheck" | "visualReview";
export type Effort = "low" | "medium" | "high";
const high = { effort: "medium" as Effort, maxOutputTokens: 24000 };
const medium = { effort: "medium" as Effort, maxOutputTokens: 16000 };
const low = { effort: "low" as Effort, maxOutputTokens: 10000 };
/** All generation budgets live here. This module is safe to import in the UI. */
export const GENERATION_CONFIG = {
  version: "2026-11-07-execution-v2-quote-filter",
  stages: {
    interpretTask: { ...high }, judgment: { ...high }, story: { ...high }, assessDeck: { ...high },
    planResearch: { ...medium }, research: { ...medium }, evidence: { ...medium }, attachments: { ...medium }, candidates: { ...medium },
    formatRepair: { ...low }, headlineRepair: { ...low }, slideChat: { ...low }, keyCheck: { ...low, maxOutputTokens: 32 }, visualReview: { ...medium },
  } satisfies Record<GenerationStage, { effort: Effort; maxOutputTokens: number }>,
  outputLimitLadder: [10000, 16000, 24000, 32000],
  outputLimitRetries: 1, formatAttempts: 3, qualityRetries: 2, providerTimeoutMs: 240000,
  research: { roundsPerQuestion: 3, originalsPerQuestion: 3, originalsPerDeck: 12, matchingEvidencePerQuestion: 2, toolCallsPerQuery: 3, sourcesPerQuery: 15, queryCharacters: 500, summaryCharactersPerRound: 16000, maxPageBytes: 8 * 1024 * 1024, originalCharacters: 60000, pageTimeoutMs: 20000, redirectLimit: 3 },
  attachments: { chunkCharacters: 12000, rowsPerChunk: 80, extractVersion: "2", imagesPerExtraction: 4, contextTokens: 2400, researchTokens: 7200 },
  candidates: { maximum: 3 },
  visual: { enabled: true, width: 1280, minFontPt: 10, overlapAreaFraction: .15, toleranceInches: .025, bodyTop: 1.7, bodyBottom: 6.3, emptyBottomFraction: .30, defaultMinimumFill: .18,
    minimumFill: { "comparison-table": .20, calendar: .16, quadrants: .17, "contract-bars": .14, "formula-cards": .22, "evidence-table": .17, journey: .17, "cause-chain": .18, "system-flow": .17, swimlane: .16 } as Record<string,number> },
  reports: { topicCharacters: 36, maxRequestBytes: 4 * 1024 * 1024 },
};
export function stageSettings(stage: GenerationStage) { return { ...GENERATION_CONFIG.stages[stage] }; }
export function nextOutputLimit(current: number) { return GENERATION_CONFIG.outputLimitLadder.find(limit => limit > current) ?? current; }
