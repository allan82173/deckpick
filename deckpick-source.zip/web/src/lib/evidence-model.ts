import { z } from "zod";
import { taskAnalysisSchema, researchPlanSchema, decisionSchema, materialTypes } from "./task-model";

export const slideRoles = ["사실 제시", "비교", "흐름", "우선순위", "계산", "일정", "합의 사항", "판단", "근거", "마무리"] as const;
export const evidenceSchema = z.object({
  id: z.string().regex(/^\d+$/),
  claim: z.string().min(1).max(1600),
  title: z.string().min(1).max(240),
  url: z.union([z.literal(""), z.url().refine(value => /^https?:\/\//.test(value))]).default(""),
  checkedAt: z.string(),
  kind: z.enum(["공개 사실", "내부 전제", "추론", "미검증 가설"]),
  locator: z.string().max(500).default(""),
  originalText: z.string().max(1600).optional(),
  publishedAt: z.string().max(100).optional(),
  materialType: z.enum(materialTypes).optional(),
  contextMatch: z.enum(["일치", "비교 참고", "불명확"]).optional(),
  contextReason: z.string().max(500).optional(),
  questionIds: z.array(z.string()).max(4).optional(),
  originalVerified: z.boolean().optional(),
  attachmentType: z.enum(["내부 전제", "일정", "조건", "목표", "제약", "기타"]).optional(),
});
export type Evidence = z.infer<typeof evidenceSchema>;
export const researchRecordSchema = z.object({
  evidence: z.array(evidenceSchema),
  attachmentFingerprint: z.string().optional(),
  confirmedDecisions: z.array(z.object({ id:z.string(), text:z.string(), locator:z.string(), confirmedAt:z.string() })).optional(),
  searchRounds: z.array(z.object({questionId:z.string(),round:z.number(),queries:z.array(z.string()),matchedEvidence:z.number()})).optional(),
  searchStatus: z.enum(["searched", "unavailable", "not-requested"]),
  notice: z.string(),
  query: z.string(),
  analysis: taskAnalysisSchema.optional(),
  plan: researchPlanSchema.optional(),
  decisions: z.array(decisionSchema).optional(),
  gaps: z.array(z.object({ questionId: z.string(), question: z.string(), missing: z.string() })).optional(),
  requiresReview: z.boolean().optional(),
  acceptedLimits: z.boolean().optional(),
  queries: z.array(z.string()).optional(),
  originalPages: z.array(z.object({ url: z.string(), opened: z.boolean(), checkedAt: z.string(), error: z.string().optional(), format:z.enum(["html","text","pdf"]).optional(), questionIds:z.array(z.string()).optional() })).optional(),
});
export type ResearchRecord = z.infer<typeof researchRecordSchema>;
export const slideQualitySchema = z.object({
  warnings: z.array(z.string()),
  attempts: z.number().int().min(0).max(2),
  fillRatio: z.number().min(0).max(1),
  visual: z.object({status:z.enum(["passed","issues","failed","disabled"]),warnings:z.array(z.string())}).optional(),
});
